var searchData=
[
  ['stops_0',['stops',['../_management_8cpp.html#a9e68de9b5e28cbc1e6f974935cc3ae85',1,'Management.cpp']]]
];
