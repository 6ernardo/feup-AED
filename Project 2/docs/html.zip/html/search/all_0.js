var searchData=
[
  ['addedge_0',['addEdge',['../class_graph.html#a982e21d86e6760caa4dc901091103a2c',1,'Graph']]],
  ['addlinetograph_1',['addLineToGraph',['../class_management.html#aecc2191fea5f7a619bfdcbee0bed82d9',1,'Management']]]
];
