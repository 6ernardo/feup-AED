var searchData=
[
  ['lines_0',['lines',['../_management_8cpp.html#ace68ce5f7f4ca314c9f25a0b31a731f5',1,'Management.cpp']]]
];
