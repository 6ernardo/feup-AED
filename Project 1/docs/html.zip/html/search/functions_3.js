var searchData=
[
  ['defineplane_0',['definePlane',['../class_management.html#a7e8cc9cfea12500ac97789f10f008fc5',1,'Management']]]
];
