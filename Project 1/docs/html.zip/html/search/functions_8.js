var searchData=
[
  ['mainmenu_0',['mainMenu',['../class_management.html#ac74da37d238f1cf4bae037cc41cf0041',1,'Management']]],
  ['management_1',['Management',['../class_management.html#af6443089434984f915086ab2526b570b',1,'Management']]]
];
