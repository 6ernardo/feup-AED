var searchData=
[
  ['management_0',['Management',['../class_management.html',1,'']]]
];
