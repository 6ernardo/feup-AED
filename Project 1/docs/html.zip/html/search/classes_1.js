var searchData=
[
  ['date_0',['Date',['../struct_date.html',1,'']]]
];
