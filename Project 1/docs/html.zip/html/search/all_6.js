var searchData=
[
  ['insertluggage_0',['insertLuggage',['../class_management.html#a54fbe038b0a796fd3944bba202af0ef4',1,'Management']]]
];
